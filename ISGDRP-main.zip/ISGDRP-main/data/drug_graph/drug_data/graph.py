import numpy as np
import pandas as pd
import os
import csv
import scipy
import torch
import torch.nn as nn
from torch_geometric.data import Data, Batch
from torch_geometric.nn import graclus, max_pool
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
import pickle
import math

import dgl


def get_drug_graph(drug_path):  # string数据集，PPI

    # edge_index
    with open("../drug_sim_matrix_jac.pkl", "rb") as file:
        drug_sim_matrix = pickle.load(file)

    edge_index = []
    edge_attr = []
    for i in range(170):
        for j in range(170):
            if i != j:
                # if math.isclose(drug_sim_matrix[i][j], 0, rel_tol=1e-5):
                if  drug_sim_matrix[i][j]<0.8:
                    continue
                else:
                    edge_index.append((i, j))
                    edge_index.append((j, i))
                    edge_attr.append(drug_sim_matrix[i][j])
                    edge_attr.append(drug_sim_matrix[i][j])
    edge_index = list((edge_index))
    edge_index = np.array(edge_index, dtype=np.int64).T
    edge_attr = np.array(edge_attr, dtype=np.float64).T
    np.save(
        os.path.join('edge_index.npy'), edge_index)

    return edge_index, edge_attr


def save_drug_graph(genes_path, save_path, edge_index, edge_attr):
    with open("zxy_drug_disease.pkl", "rb") as file:
        drug_disease = pickle.load(file)
    with open("zxy_drug_gene_all.pkl", "rb") as file:
        drug_gene = pickle.load(file)
    with open("zxy_drug_ADR.pkl", "rb") as file:
        drug_ADR = pickle.load(file)
    with open("zxy_drug_miRNA.pkl", "rb") as file:
        drug_miRNA = pickle.load(file)
    with open("zxy_stitch_combined_score.pkl", "rb") as file:
        drug_drug = pickle.load(file)
    with open("../../IC50/ic_170drug_580cell.pkl", "rb") as file:
        drug_cell = pickle.load(file)
    drug_target_dict = {}
    drug_dis_dict = {}
    drug_drug_dict = {}
    drug_miRNA_dict = {}
    drug_ADR_dict = {}
    drug_target_dict['graph'] = Data(x=torch.tensor(drug_gene, dtype=torch.float),
                                            edge_index=torch.tensor(edge_index, dtype=torch.int32),
                                            edge_attr=torch.tensor(edge_attr, dtype=torch.float64))

    drug_dis_dict['graph'] = Data(x=torch.tensor(drug_disease, dtype=torch.float),
                                            edge_index=torch.tensor(edge_index, dtype=torch.int32),
                                            edge_attr=torch.tensor(edge_attr, dtype=torch.float64))

    drug_drug_dict['graph'] = Data(x=torch.tensor(drug_drug, dtype=torch.float),
                                            edge_index=torch.tensor(edge_index, dtype=torch.int32),
                                            edge_attr=torch.tensor(edge_attr, dtype=torch.float64))

    drug_miRNA_dict['graph'] = Data(x=torch.tensor(drug_miRNA, dtype=torch.float),
                                            edge_index=torch.tensor(edge_index, dtype=torch.int32),
                                            edge_attr=torch.tensor(edge_attr, dtype=torch.float64))

    drug_ADR_dict['graph'] = Data(x=torch.tensor(drug_ADR, dtype=torch.float),
                                            edge_index=torch.tensor(edge_index, dtype=torch.int32),
                                            edge_attr=torch.tensor(edge_attr, dtype=torch.float64))

    np.save(os.path.join(save_path, 'drug_target_dict.npy'), drug_target_dict)

    np.save(os.path.join(save_path, 'drug_dis_dict.npy'), drug_dis_dict)

    np.save(os.path.join(save_path, 'drug_drug_dict.npy'), drug_drug_dict)
    np.save(os.path.join(save_path, 'drug_ADR_dict.npy'), drug_ADR_dict)
    np.save(os.path.join(save_path, 'drug_miRNA_dict.npy'), drug_miRNA_dict)

    print("finish saving cell mut data!")


if __name__ == '__main__':
    drug_path = ''
    save_path = 'raw_sim08_jac/'
    edge_index, edge_attr = get_drug_graph(drug_path)
    save_drug_graph(drug_path, save_path, edge_index, edge_attr)

